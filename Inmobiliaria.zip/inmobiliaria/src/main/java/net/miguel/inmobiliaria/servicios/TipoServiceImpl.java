package net.miguel.inmobiliaria.servicios;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import net.miguel.inmobiliaria.entidades.Tipo;
import net.miguel.inmobiliaria.repositorios.TipoRepository;

@Service
public class TipoServiceImpl implements TipoService {
	@Autowired
	private TipoRepository repo;
	
	@Override
	public Iterable<Tipo> obtenerTipos() {
		return repo.findAll();
	}
	
}
