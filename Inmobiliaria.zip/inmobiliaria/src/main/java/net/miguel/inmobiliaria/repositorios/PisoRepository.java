package net.miguel.inmobiliaria.repositorios;

import org.springframework.data.repository.*;
import org.springframework.data.rest.core.annotation.*;

import net.miguel.inmobiliaria.entidades.Piso;

@RepositoryRestResource(collectionResourceRel = "pisos", path = "pisos")
public interface PisoRepository extends PagingAndSortingRepository<Piso, Long> {

}
