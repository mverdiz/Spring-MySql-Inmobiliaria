package net.miguel.inmobiliaria.servicios;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import lombok.extern.java.*;
import net.miguel.inmobiliaria.entidades.Piso;
import net.miguel.inmobiliaria.repositorios.PisoRepository;

@Log
@Service
public class PisoServiceImpl implements PisoService {
	@Autowired
	private PisoRepository repo;
	
	@Override
	public Iterable<Piso> listado() {
		log.info("Se han pedido todos los pisos");
		return repo.findAll();
	}

	@Override
	public Piso obtenerPorId(Long id) {
		log.info("Se ha pedido el piso " + id);
		return repo.findById(id).orElse(null);
	}

	@Override
	public Piso insertar(Piso piso) {
		log.info("Se va a insertar el piso " + piso);
		piso.setId(null);
		return repo.save(piso);
	}

	@Override
	public Piso modificar(Piso piso) {
		log.info("Se va a modificar el piso " + piso);
		log.info("con el tipo:" + piso.getTipo());
		
		return repo.save(piso);
	}

	@Override
	public void borrar(Long id) {
		log.info("Se va a borrar el piso " + id);
		repo.deleteById(id);
	}
}
