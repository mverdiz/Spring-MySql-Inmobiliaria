package net.miguel.inmobiliaria.servicios;

import net.miguel.inmobiliaria.entidades.Tipo;

public interface TipoService {
	Iterable<Tipo> obtenerTipos();
}
