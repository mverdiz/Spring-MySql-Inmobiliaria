package net.miguel.inmobiliaria.controladores;

import javax.validation.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.ui.*;
import org.springframework.validation.*;
import org.springframework.web.bind.annotation.*;

import lombok.extern.java.*;
import net.miguel.inmobiliaria.entidades.Piso;
import net.miguel.inmobiliaria.servicios.PisoService;
import net.miguel.inmobiliaria.servicios.TipoService;

@Log
@Controller
@RequestMapping("/admin/pisos")
public class AdminPisosController {
	@Autowired
	private TipoService servicioTipo;
	@Autowired
	private PisoService servicio;
	
	@GetMapping
	public String pisos(Model modelo) {
		modelo.addAttribute("pisos", servicio.listado());
		return "admin/pisos";
	}
	
	@GetMapping("/insertar")
	public String insertar(Piso piso , Model modelo) {
		modelo.addAttribute("tipos", servicioTipo.obtenerTipos());
		return "admin/piso";
	}

	@GetMapping("/{id}")
	public String editar(@PathVariable Long id, Model modelo) {
		modelo.addAttribute("tipos", servicioTipo.obtenerTipos());
		modelo.addAttribute("piso", servicio.obtenerPorId(id));
		return "admin/piso";
	}

	@GetMapping("/{id}/borrar")
	public String borrar(@PathVariable Long id) {
		servicio.borrar(id);
		return "redirect:/admin/pisos";
	}
	
	@PostMapping
	public String postPelicula(@Valid Piso piso, BindingResult bindingResult) {
		log.info(piso.toString());
		log.info(piso.getTipo().toString());
		
		if(bindingResult.hasErrors()) {
			return "admin/piso";
		}
		
		if(piso.getId() == null) {
			servicio.insertar(piso);
		} else {
			servicio.modificar(piso);
		}
		
		return "redirect:/admin/pisos";
	}
}
