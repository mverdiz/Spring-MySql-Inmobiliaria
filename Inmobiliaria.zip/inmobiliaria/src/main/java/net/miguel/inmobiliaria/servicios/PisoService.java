package net.miguel.inmobiliaria.servicios;

import net.miguel.inmobiliaria.entidades.Piso;

public interface PisoService {
	Iterable<Piso> listado();
	Piso obtenerPorId(Long id);
	
	Piso insertar(Piso piso);
	Piso modificar(Piso piso);
	void borrar(Long id);
}
