package net.miguel.inmobiliaria.repositorios;

import org.springframework.data.repository.*;
import org.springframework.data.rest.core.annotation.*;

import net.miguel.inmobiliaria.entidades.Tipo;

@RepositoryRestResource(collectionResourceRel = "tipos", path = "tipos")
public interface TipoRepository extends PagingAndSortingRepository<Tipo, Long> {

}
