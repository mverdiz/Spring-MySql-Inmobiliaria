package net.miguel.inmobiliaria.controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import net.miguel.inmobiliaria.entidades.Piso;
import net.miguel.inmobiliaria.servicios.PisoService;
import net.miguel.inmobiliaria.servicios.TipoService;

@Controller
@RequestMapping("/")
public class IndexController {
	@Autowired
	private TipoService servicioTipo;
	@Autowired
	private PisoService servicio;
	
	@GetMapping
	public String index(Piso piso, Model modelo) {
		modelo.addAttribute("tipos", servicioTipo.obtenerTipos());
		modelo.addAttribute("pisos", servicio.listado());
		
		return "index";
	}
	
	
	@GetMapping("/prueba")
	public String prueba() {
		return "prueba";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}
}
